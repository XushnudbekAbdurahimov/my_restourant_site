import React from 'react'
import './owner.css'




const Owner = () => {
     return (
          <div className='owner'>

               <table>
                    <thead>
                    <tr className='tr'>
                         <th>№</th>
                         <th>Ismi</th>
                         <th>Familya</th>
                         <th>Vazifa</th>
                    </tr>
                    </thead>
                    <tbody>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                         <tr>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         <td>mhngbv</td>
                         </tr>
                    </tbody>
               </table>







          </div>
     )
}

export default Owner
