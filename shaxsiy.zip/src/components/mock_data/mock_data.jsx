const mock_data = [
     {
          id: 1,
          title: "Ovqat",
          ovqat: "Palov",
          img: "https://png.pngtree.com/thumb_back/fw800/background/20220314/pngtree-pilaf-palov-arabian-plov-photo-image_21735806.jpg",
     },
     {
          id: 2,
          title: "Ovqat",
          ovqat: "Sho'rva"
     },
     {
          id: 3,
          title: "Ovqat",
          ovqat: "Grill"
     },
     {
          id: 4,
          title: "Ovqat",
          ovqat: "Mastava"
        },
        {
          id: 5,
          title: "Ovqat",
          ovqat: "Qotirma"
        },
        {
          id: 6,
          title: "Ovqat",
          ovqat: "Mastava"
        },
        {
          id: 7,
          title: "Ovqat",
          ovqat: "Bifshtaiks"
        },
        {
          id: 8,
          title: "Ovqat",
          ovqat: "Palov"
        },
        {
          id: 9,
          title: "Ovqat",
          ovqat: "Palov"
        },
        {
          id: 10,
          title: "Ovqat",
          salad: "Sezar"
        },
        {
          id: 11,
          title: "Ovqat",
          salad: "Fransuzcha"
        },
        {
          id: 12,
          title: "Ovqat",
          salad: "Penchuza"
        },
        {
          id: 13,
          title: "Ovqat",
          salad: "Binnasa"
        },
        {
          id: 14,
          title: "Ovqat",
          shirinlik: "Tort"
        },
        {
          id: 15,
          title: "Ovqat",
          shirinlik: "Qora choy"
        },
        {
          id: 16,
          title: "Ovqat",
          shirinlik: "Ko'k choy"
        },
        {
          id: 17,
          title: "Ovqat",
          shirinlik: "Ko'k choy"
        },
        {
          id: 18,
          title: "Ovqat",
          suv: "Coffee"
        },
        {
          id: 19,
          title: "Ovqat",
          suv: "Qora choy"
        },
        {
          id: 21,
          title: "Ovqat",
          suv: "Ko'k choy"
        },
        {
          id: 22,
          title: "Ovqat",
          suv: "Coca Cola"
        },
        {
          id: 23,
          title: "Ovqat",
          suv: "Fanta"
        },
        {
          id: 24,
          title: "Ovqat",
          suv: "Pepsi"
        },
        {
          id: 25,
          title: "Ovqat",
          suv: "Sprite"
        },
]
export default mock_data