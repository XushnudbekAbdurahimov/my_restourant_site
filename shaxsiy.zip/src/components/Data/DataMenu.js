const DataMenu = {
  ovqatlar: [
    {
      id: 1,
      title: "Ovqat",
      ovqat: "Palov",
    },
    {
      id: 2,
      title: "Ovqat",
      ovqat: "Sho'rva"
    },
    {
      id: 3,
      title: "Ovqat",
      ovqat: "Grill"
    },
    {
      id: 4,
      title: "Ovqat",
      ovqat: "Mastava"
    },
    {
      id: 5,
      title: "Ovqat",
      ovqat: "Qotirma"
    },
    {
      id: 6,
      title: "Ovqat",
      ovqat: "Mastava"
    },
    {
      id: 7,
      title: "Ovqat",
      ovqat: "Bifshtaiks"
    },
    {
      id: 8,
      title: "Ovqat",
      ovqat: "Palov"
    },
    {
      id: 9,
      title: "Ovqat",
      ovqat: "Palov"
    },
  ],
  saladlar: [
    {
      id: 10,
      title: "Ovqat",
      salad: "Sezar"
    },
    {
      id: 11,
      title: "Ovqat",
      salad: "Fransuzcha"
    },
    {
      id: 12,
      title: "Ovqat",
      salad: "Penchuza"
    },
    {
      id: 13,
      title: "Ovqat",
      salad: "Binnasa"
    },
  ],
  shirinliklar: [
    {
      id: 14,
      title: "Ovqat",
      shirinlik: "Tort"
    },
    {
      id: 15,
      title: "Ovqat",
      shirinlik: "Qora choy"
    },
    {
      id: 16,
      title: "Ovqat",
      shirinlik: "Ko'k choy"
    },
    {
      id: 17,
      title: "Ovqat",
      shirinlik: "Ko'k choy"
    },
  ],
  suvlar: {
    gazsizlar: [
      {
        id: 18,
        title: "Ovqat",
        suv: "Coffee"
      },
      {
        id: 19,
        title: "Ovqat",
        suv: "Qora choy"
      },
      {
        id: 21,
        title: "Ovqat",
        suv: "Ko'k choy"
      },
    ],
    gazlilar: [
      {
        id: 22,
        title: "Ovqat",
        suv: "Coca Cola"
      },
      {
        id: 23,
        title: "Ovqat",
        suv: "Fanta"
      },
      {
        id: 24,
        title: "Ovqat",
        suv: "Pepsi"
      },
      {
        id: 25,
        title: "Ovqat",
        suv: "Sprite"
      },
    ],
  },
};

export default DataMenu;
