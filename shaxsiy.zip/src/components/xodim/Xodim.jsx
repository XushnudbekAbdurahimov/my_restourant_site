import React from "react";
import './xodim.css'
import { Link } from "react-router-dom";


const Xodim = () => {
     return (
          <div className="xodim">
               <h1 className="afit">Afitsant</h1>
               <div className="cards">
                    <div className="stol">
                         <h1>1-stol</h1>
                         <hr />
                         <h3>Retsept:</h3>
                         <ul>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                         </ul>
                         <button>Submit</button>

                    </div>
                    <div className="stol">
                         <h1>2-stol</h1>
                         <hr />
                         <h3>Retsept:</h3>
                         <ul>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                         </ul>
                         <button>Submit</button>
                    </div>
                    <div className="stol">
                         <h1>3-stol</h1>
                         <hr />
                         <h3>Retsept:</h3>
                         <ul>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                         </ul>
                         <button>Submit</button>
                    </div>
                    <div className="stol">
                         <h1>4-stol</h1>
                         <hr />
                         <h3>Retsept:</h3>
                         <ul>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                         </ul>
                         <button>Submit</button>
                    </div>
                    <div className="stol">
                         <h1>5-stol</h1>
                         <hr />
                         <h3>Retsept:</h3>
                         <ul>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                         </ul>
                         <button>Submit</button>
                    </div>
                    <div className="stol">
                         <h1>6-stol</h1>
                         <hr />
                         <h3>Retsept:</h3>
                         <ul>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                         </ul>
                         <button>Submit</button>
                    </div>
                    <div className="stol">
                         <h1>7-stol</h1>
                         <hr />
                         <h3>Retsept:</h3>
                         <ul>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                         </ul>
                         <button>Submit</button>
                    </div>
                    <div className="stol">
                         <h1>8-stol</h1>
                         <hr />
                         <h3>Retsept:</h3>
                         <ul>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                              <li>

                              </li>
                         </ul>
                         <button>Submit</button>
                    </div>
               </div>

          </div>
     )
}
export default Xodim

