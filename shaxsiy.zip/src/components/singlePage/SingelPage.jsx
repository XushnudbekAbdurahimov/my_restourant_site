import React from 'react'
import { useParams } from 'react-router'
import DataMenu from '../Data/DataMenu'
import mock_data from '../mock_data/mock_data'
import './page.css'
import { useCart } from "react-use-cart"
// import '../node_modules/bootstrap/dist/css/bootstrap.min.css'


const SingelPage = () => {
     const { id } = useParams();
     const result = mock_data.filter(item => item.id == id);

     const { addItem } = useCart()

     return (
          <div className='cards_s'>
               {result.map((item, index) => (
                    <div key={index} className="Card">
                         <h1>{item.title}</h1>
                         <img src={item.img} className="card_image" />

                         <div className="btnn">
                              <button onClick={() => addItem()}>Add to Cart</button>
                         </div>
                    </div>
               ))}
          </div>
     );
}

export default SingelPage
