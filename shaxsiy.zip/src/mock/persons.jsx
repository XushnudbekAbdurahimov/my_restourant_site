const allData = [
     {
          id: 1,
          Fullname: 'Alijon Jalilov',
          age: 24,
          phone: 9998655564654,
          images: ["https://images.uzum.uz/cjhgmc4vutve1vhnunkg/original.jpg", "https://images.uzum.uz/cjhgmcbk9fqe2mb6c670/original.jpg", "https://images.uzum.uz/cjhgmc4jvf2i5uiugmfg/original.jpg", "https://images.uzum.uz/cjdgo8rk9fqdtbu5tnhg/original.jpg", "https://images.uzum.uz/cjhgmc4jvf2i5uiugmg0/original.jpg"],
          cotigory: "owner",
          login: "alijon",
          parol: "jalilov",

     },   
     {
          id: 2,
          Fullname: 'Andrey Pavlov',
          age: 65,
          phone: 9998655564654,
          images: ["https://images.uzum.uz/cjhgmc4vutve1vhnunkg/original.jpg", "https://images.uzum.uz/cjhgmcbk9fqe2mb6c670/original.jpg", "https://images.uzum.uz/cjhgmc4jvf2i5uiugmfg/original.jpg", "https://images.uzum.uz/cjdgo8rk9fqdtbu5tnhg/original.jpg", "https://images.uzum.uz/cjhgmc4jvf2i5uiugmg0/original.jpg"],
          cotigory: "owner",
          login: "andrey",
          parol: "pavlov",

     },

     {
          id: 3,
          Fullname: 'Lola Alimjonova',
          age: 18,
          phone: 9998655564654,
          images: ["https://images.uzum.uz/cjhgmc4vutve1vhnunkg/original.jpg", "https://images.uzum.uz/cjhgmcbk9fqe2mb6c670/original.jpg", "https://images.uzum.uz/cjhgmc4jvf2i5uiugmfg/original.jpg", "https://images.uzum.uz/cjdgo8rk9fqdtbu5tnhg/original.jpg", "https://images.uzum.uz/cjhgmc4jvf2i5uiugmg0/original.jpg"],
          cotigory: "cooker",
          login: "lola",
          parol: "alimjonova",

     },
]

export default allData;